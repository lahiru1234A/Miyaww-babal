# සිංහල WhatsApp AI Bot – ආරම්භක ව්‍යාපෘතිය

මෙය Meta හි නිල WhatsApp Cloud API සහ OpenAI Responses API භාවිතා කරන සරල ආරම්භක bot එකකි. මෙය Android Chrome එකෙන් setup කළ හැකි නමුත් bot එක දිගටම ක්‍රියාත්මක වීමට cloud hosting අවශ්‍ය වේ.

## අවශ්‍ය දේ
- Meta Developer account සහ WhatsApp Business Platform / Cloud API setup
- OpenAI API key (API භාවිතය සඳහා ගාස්තු අය විය හැක)
- HTTPS සහිත Node.js hosting
- පණිවිඩ ලැබීමට Meta webhook එකක්

## පියවර
1. මෙම ZIP එක extract කරන්න.
2. Hosting සේවාවක Node.js web service එකක් සාදා මේ files upload කරන්න.
3. `npm install` සහ `npm start` ක්‍රියාත්මක කරන්න (සාමාන්‍යයෙන් hosting එක මෙය කරයි).
4. `.env.example` හි පිටපතක් `.env` ලෙස සාදා සියලුම අගයන් hosting එකේ Environment Variables ලෙස ඇතුළත් කරන්න.
5. `OPENAI_API_KEY` OpenAI Platform වෙතින් ගන්න.
6. Meta Developers හි WhatsApp > API Setup වෙතින් access token සහ Phone Number ID ගන්න.
7. `WHATSAPP_VERIFY_TOKEN` සඳහා ඔබම හදන දිගු රහස් වචනයක් යොදන්න.
8. Meta WhatsApp webhook callback URL ලෙස `https://YOUR-HOST/webhook` යොදන්න. Verify token එකත් ඒ අගයට සමාන විය යුතුයි.
9. Webhook subscriptions තුළ `messages` තෝරන්න.
10. Meta test number එකෙන් bot එකට පණිවිඩයක් යවා පරීක්ෂා කරන්න.

## වැදගත්
- `.env` හෝ API keys කිසිවෙකුට යවන්න එපා; GitHub වෙත upload නොකරන්න.
- සාමාන්‍ය WhatsApp පුද්ගලික අංකයක් automate කිරීමට unofficial libraries භාවිතා නොකරන්න. නිල Cloud API භාවිතා කරන්න.
- Meta හි messaging window, template සහ business rules අනුගමනය කරන්න.
- OpenAI API සහ hosting සඳහා ගාස්තු තිබිය හැක.
- මෙම starter එක text messages සඳහා පමණි; image, audio, voice සහ chat history තවම එකතු කර නැත.
- Meta Graph API version එක deploy කරන දිනයේ Meta dashboard/docs හි සහාය දක්වන version එකට ගළපන්න (`META_GRAPH_VERSION`).
