import "dotenv/config";
import express from "express";

const app = express();
app.use(express.json());

const {
  OPENAI_API_KEY,
  OPENAI_MODEL = "gpt-6-astra",
  WHATSAPP_TOKEN,
  WHATSAPP_PHONE_NUMBER_ID,
  WHATSAPP_VERIFY_TOKEN,
  META_GRAPH_VERSION = "v23.0",
  PORT = 3000
} = process.env;

app.get("/", (_req, res) => res.status(200).send("Sinhala WhatsApp AI bot is running."));

app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

async function askAI(userText) {
  if (!OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is missing");

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      instructions:
        "You are a friendly, helpful WhatsApp assistant. Reply naturally in Sinhala when the user writes Sinhala, and understand Singlish (Sinhala written in Latin letters). Keep replies concise and respectful. If unsure, say so. Do not claim to be a human.",
      input: userText,
      max_output_tokens: 500
    })
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`OpenAI API error ${response.status}: ${detail}`);
  }
  const data = await response.json();
  return (data.output || [])
    .filter(item => item.type === "message")
    .flatMap(item => item.content || [])
    .filter(part => part.type === "output_text")
    .map(part => part.text)
    .join("\n").trim() || "සමාවෙන්න, දැන් පිළිතුරක් ලබාගන්න බැහැ.";
}

async function sendWhatsAppText(to, body) {
  if (!WHATSAPP_TOKEN || !WHATSAPP_PHONE_NUMBER_ID) {
    throw new Error("WhatsApp credentials are missing");
  }

  const url = `https://graph.facebook.com/${META_GRAPH_VERSION}/${WHATSAPP_PHONE_NUMBER_ID}/messages`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${WHATSAPP_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body: String(body).slice(0, 4000) }
    })
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`WhatsApp API error ${response.status}: ${detail}`);
  }
}

app.post("/webhook", async (req, res) => {
  // Acknowledge Meta quickly; process the event asynchronously.
  res.sendStatus(200);

  try {
    const entries = req.body?.entry || [];
    for (const entry of entries) {
      for (const change of entry.changes || []) {
        const messages = change.value?.messages || [];
        for (const message of messages) {
          if (message.type !== "text" || !message.from || !message.text?.body) continue;

          const from = message.from;
          const userText = message.text.body;

          try {
            const answer = await askAI(userText);
            await sendWhatsAppText(from, answer);
          } catch (err) {
            console.error("Message processing failed:", err.message);
            // Avoid exposing internal error details to WhatsApp users.
            await sendWhatsAppText(from, "සමාවෙන්න, දැන් ටිකක් තාක්ෂණික ගැටලුවක් තියෙනවා. පසුව නැවත උත්සාහ කරන්න.");
          }
        }
      }
    }
  } catch (err) {
    console.error("Webhook error:", err);
  }
});

app.listen(PORT, () => console.log(`Bot server listening on port ${PORT}`));
